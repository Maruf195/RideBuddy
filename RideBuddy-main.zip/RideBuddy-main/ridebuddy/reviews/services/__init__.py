# Init for reviews services
