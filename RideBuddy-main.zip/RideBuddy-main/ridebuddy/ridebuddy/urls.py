"""
URL configuration for ridebuddy project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('analytics/', include("analytics.urls")),
    path('', include("accounts.urls")),
    path('', include("bookings.urls")),
    path('', include("reviews.urls")),
    path('rides/', include("rides.urls")),
    path('accounts/', include('django.contrib.auth.urls')),
    
    # Root-level SEO and PWA files
    path('service-worker.js', (TemplateView.as_view(template_name="service-worker.js", content_type='application/javascript', ))),
    path('manifest.json', (TemplateView.as_view(template_name="manifest.json", content_type='application/json', ))),
]
